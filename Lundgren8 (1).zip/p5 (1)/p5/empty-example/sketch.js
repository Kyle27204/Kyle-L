
var img1;
var img2;
function preload() {

	img1 = loadImage("Wizard.png");
	img2 = loadImage("200px-Rotating_earth_(large).gif");
fontSans = loadfont('Oswald-VariableFont_wght.ttf');

}

function setup () {

	createCanvas(480, 400);
fill(10,10,50);
textSize(15);
let s = ('This is a Warforged Wizard');
text(s, 130, 210, 200, 200);
strokeWeight(0);

}

function draw () {

	image(img1, 130, 0, 200, 200);
image(img2, 130, 250, 200, 200);
	
	textFont(fontSans);
}