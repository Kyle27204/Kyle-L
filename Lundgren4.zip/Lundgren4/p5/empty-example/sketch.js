var x = 155;

var x2 = 255;

var x3 = 175;

var y = 255;

var y2= 255;

var y3 = 135;

var w = 50;

var h = 50;

function setup() {
  
  createCanvas(400, 400);

}

let value = 0;

function draw() {
  
  background(220);
  
    if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) 
    if (keyIsPressed === true) {
   
    fill(5);

  } else {
   
    fill(235);
  }
   ellipse(x, y, w, h); {

  fill(value);
  }
  ellipse(x2,y2,w,h); {

  }
  fill(value);
  rect(x3,y3,w,h); {
}

}
function mouseClicked() {
  if (value === 0) {
   
    value = 255;
  
  } else {
   
    value = 0;

  }

}