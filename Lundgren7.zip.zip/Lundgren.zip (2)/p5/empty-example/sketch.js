
var num = 60;

var x = [];
var y = [];
var x2 = [];
var x3 = [];
var y2 = [];
var y3 = [];
var z = [];
function setup() {

	createCanvas(400, 400);

	noStroke();

	for (var i = 0; i < num; i++) {

		x[i] = 0;

		y[i] = 0;

	}
for (var i = 0; i < 3000; i++) {

		//assign values to array based on for loop
		x2[i] = random(-1000, 200); 
}
}
function draw() {

	background(0);

	// Copy array values from back to front

	for (var i = num-1; i > 0; i--) {

		x[i] = x[i-1];

		y[i] = y[i-1];
	}

	x[0] = mouseX; // Set the first element

	y[0] = mouseY; // Set the first element

	for (var i = 0; i < num; i++) {

		fill(i * 4);

		ellipse(x[i], y[i], 40, 40);
	}
for (var i = 0; i < x2.length; i++) {
  x2[i] +=1.5;
var y2 = i * 5;
arc(x2[i], y2, 12, 12, 0.52, 5.76);
}
  var x3 = [13, 20]; {
print(x.length); 
var y3 = ["dog", 12, false, 50]; 
print(y.length); 
var z = []; 
print(z.length); 
z[0] = 20;  
print(z.length); 
z[1] = 4; 
print(z.length); 
}
}